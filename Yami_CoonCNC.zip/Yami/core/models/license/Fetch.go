package License

import (
	"log"
)


func LicenseGet() bool {
		log.Println("Neko/SuCCuBuS on top FB has crabs")

	return true
}

/*
	for {
		licenseKey, err := cryptolens.KeyActivate(token, cryptolens.KeyActivateArguments{
			ProductId:   11343,
			Key:         string(Key),
		})
	
		if err != nil || !licenseKey.HasValidSignature(publicKey) {
			fmt.Println("License key activation failed!")
			os.Exit(1337)
		}
	
		if time.Now().After(licenseKey.Expires) {
			fmt.Println("License key has expired")
			os.Exit(1337)
		}

		time.Sleep(12 * time.Hour)
	}
	*/