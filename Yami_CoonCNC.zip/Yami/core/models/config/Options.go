package Options

var (
	Devolper = "FBv9 & DownMyPath"

	Attacks = 0





	ClientVersion = "v1.2.60 (BETA)"

	LicensePPKFile = "build/license.key"
)