package slaves

import (
	"log"
)

//Configure sets up everything slaves need before the CNC starts
func Configure() {

	log.Println(" [Slave IP Ban] [Active]")
}
